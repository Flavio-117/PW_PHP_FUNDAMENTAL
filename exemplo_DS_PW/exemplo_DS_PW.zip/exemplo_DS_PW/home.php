<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>

<body>
    <h1>Variáveis e coonstantes PHP</h1>
    <?php
        //variável
        /*

        */
        $a = 67; //int
        $b = 0.67; //float
        $c = "string";
        $d = 'string';
        $e = null;
        $TESTE = false;

        //Constante
        define ("MINHA_CONST", "Não é um teste, corra");
        const SUA_CONST = "É um teste, fique";    

        //Escrevendo na tela
        echo "<p>O valor de a é " . $a . "</p>\n"; //+ é apenas para somar
        echo "\t<p>O valor de b é \$b</p>\n"; // Com ' ' o texto é tratado como uma cadeia de carecteres.
        print "\t<p>O valor de a + b é " . ($a + $b) . "</p>\n"; // Print é para deixar mais agradável, mas é a mesma coisa de echo.
        
        // " Isso é aspas, ' isso é apótrofo. "" interpreta, ' escreve literal.

        //Objeto DateTime
        $data = new DateTime("now",
         new DateTimeZone("America/Sao_Paulo"));
        echo "\t<p>A data e hora atual é {$data->format("d/m/Y - H:i:s")}</p>\n";
    ?>
    <h1>Estruturas de decisão</h1>
    <?php
        if ($a > $b) {
            echo "\t<p>deu verdadeiro</p>";
        } 
        else if ($a == $c && $b < $a) // and e && pode ser utilizado
        { 
            echo "\t<p>A é igual a C</p>";
        } 
    ?>
    <h2>Switch</h2>
    <?php
    if ($a > $b) {
        switch ($variable) {
        case 'value':
            # code...
            break;
        
        default:
            # code...
            break;
    }
    }
    ?>
</body>

</html>